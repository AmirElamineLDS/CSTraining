﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex5_2
{
    class Program
    {
        

        
        static void Main(string[] args)
        {
            List<int> tab1 = new List<int>();
            List<int> tab2 = new List<int>();
            List<int> tab12 = new List<int>();

            int n, m;
            Console.WriteLine("length of the first array?");
            n = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("length of the second array?");
            m = Convert.ToInt32(Console.ReadLine());

            for(int i = 0; i < n; i++)
            {
                Console.WriteLine(i+1);
                tab1.Add( Convert.ToInt32(Console.ReadLine()));

            }

            for (int i = 0; i < m; i++)
            {
                Console.WriteLine(i + 1);
                tab2.Add(Convert.ToInt32(Console.ReadLine()));

            }
            mergeAndSort(tab1, tab2, 0, n, 0, m);
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine("elem "+(i+1)+" "+tab12[i]);
                

            }
            Console.ReadLine();
        }

        private static void mergeAndSort(List<int> tab1, List<int> tab2,int start1, int end1, int start2, int end2)
        {
            if (tab1[end1/2]< tab2[end2 / 2])
            {
                mergeAndSort(tab1, tab2, start1, end1, start2, end2);

            }
        }
    }
}
