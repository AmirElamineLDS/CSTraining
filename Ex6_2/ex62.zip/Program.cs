﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex6_2
{
    class Program
    {
        static void Main(string[] args)
        {

            //int number=568,x;

            //x = number % 10;
            string number = "153";
            int range=0;
            char[] nbrs = SplitStr(number);
            Console.Write((char)nbrs[0]);
            Console.WriteLine((char)number[0]);
            double x;


            Console.WriteLine("Maximum ");
            number = Console.ReadLine();

            double TheNumber, power;

            for (int i = 1; i <= Convert.ToInt32(number); i++)
            {
                x = 0;
                for(int j = 1; j < i; j++)
                {
                    TheNumber = Convert.ToInt32((char)number[i]);
                    power = Convert.ToInt32(number.Length);
                    x = x + Math.Pow(TheNumber, power);
                    //Console.Write((char)x);
                }
                if(i==x)
                Console.Write(x);
               // x = Convert.ToInt32((char)number[i]);
            }
            Console.ReadLine();
        }

        private static char[] SplitStr(string number)
        {
            List<char> tabChar = new List<char>();
            foreach(char oneChr in number)
            {
                tabChar.Add(oneChr);
            }
            return tabChar.ToArray();
        }
    }
}
