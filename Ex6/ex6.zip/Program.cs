﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex6
{
    class Program
    {
        static void Main(string[] args)
        {

            //int[] tabInt = { 1, 4, 2, 8, 3, 5, 9 };
            //int[] tabInt = { 2, 2, 2 };
            int[] tabInt = { 3, 2, 2 };
            
            int nbr = 0;
            List<string> tabString=new List<string>();
            for (int i=0; i < tabInt.Length; i++)
            {
                for (int j = i+1; j < tabInt.Length; j++)
                {
                    
                    if(tabInt[i] == tabInt[j])
                    {
                        tabString.Add("("+i+","+j+") ");
                        nbr++;
                        
                    }
                }

            }
            if(tabString.Count!=0)
            foreach(string s in tabString)
            {



                Console.WriteLine(tabString.Count + " identical pairs of indices " + s);

                

            }
            else
                Console.WriteLine("No identical pairs ");

            Console.ReadLine();
        }
    }
}
